// Lock

package src.Utilidades;

public interface LockPropio {
    
    public void takeLock(int i);
    public void releaseLock();
}
