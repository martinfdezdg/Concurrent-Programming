DG
Martin Fernandez de Diego y Belen Sanchez Centeno


Ejecucion:

Desde la carpeta principal de la practica

COMPILAR:
javac src/Cliente/*.java src/Servidor/*.java src/Mensaje/*.java src/Interfaz/*.java src/Utilidades/*.java

EJECUTAR CLIENTE:
java src/Cliente/MainCliente.java ip_cliente ip_servidor puerto_servidor

EJECUTAR SERVIDOR:
java src/Servidor/MainServidor.java ip_servidor puerto_servidor